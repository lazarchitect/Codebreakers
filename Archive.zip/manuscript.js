function notify() {
    alert("So... you have chosen... to sign up");
}
